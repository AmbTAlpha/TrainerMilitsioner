@echo off
cd /d "%~dp0"
echo Installation des outils de construction...
py -m pip install --upgrade pyinstaller customtkinter pillow
if errorlevel 1 python -m pip install --upgrade pyinstaller customtkinter pillow
echo.
echo Construction du trainer...
py build_release.py
if errorlevel 1 python build_release.py
echo.
echo Termine. Le zip pret pour Nexus est dans le dossier release.
pause
